This is ProFont for Linux/UNIX X Windows, build by Gareth Redman.

To get the full original Distribution, other ProFont builds
and more information
go to <http://tobiasjung.name/profont/>


DISCLAIMER
See LICENSE file


INSTALLATION
xset -fp /usr/share/fonts/misc
xset -fp rehash
fc-list | grep ProFont # check if installed


Tobias Jung
January 2014
profont@tobiasjung.name
